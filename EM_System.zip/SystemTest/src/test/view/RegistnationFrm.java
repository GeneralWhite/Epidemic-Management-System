package test.view;

import test.dao.RegistDao;
import test.model.Regist;
import test.util.DBUtil;
import test.util.StringUtil;
import test.view.Regist_Component.False_Jl;
import test.view.Regist_Component.True_Jl;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ItemEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.sql.Connection;
import java.text.SimpleDateFormat;
import java.awt.event.ActionListener;

public
class RegistnationFrm extends JInternalFrame {

    private static final True_Jl  trueJl  = new True_Jl ( );
    private static final False_Jl falseJl = new False_Jl ( );
    private static JLabel backpactureJLabel;
    private final DBUtil dbUtil = new DBUtil();
    private final JComboBox<String> jcm1;
    private final JRadioButton jr1 = null;
    private final JTextField jt1 = null;
    private final JButton Commit_Button = null;
    private String RegistIf;
    private String TrueType;
    private JTextField Truefield1;
    private JTextField Truejfield2;
    private JTextField Falsejfield1;
    private JTextField Falsejfield2;
    private JRadioButton Ratiobutton_check;
    private JTextField TextField_check;
    

    public static void main ( String[] args ) {
        EventQueue.invokeLater ( ( ) -> {
            try {
                RegistnationFrm registnation_inter=new RegistnationFrm(backpactureJLabel);
            } catch (Exception var2) {
                var2.printStackTrace();
            }

        } );
    }

    public RegistnationFrm(JLabel backpicture){
        this.getContentPane ().setBackground ( Color.CYAN );
        this.setTitle("新建疫苗信息");
        RegistnationFrm.backpactureJLabel = backpicture;
        this.setIconifiable(true);
        this.setClosable(true);
        this.setBounds(100, 100, 1028, 783);



        JPanel jp = new JPanel ( );
        jp.setBackground(new Color(189, 183, 107));
        jp.setLayout ( null );
        jp.setBounds ( 0 , 0 , 1028 , 783 );
        this.getContentPane().add ( jp );



        //是否接种新冠疫苗选项
        JLabel jl1 = new JLabel ( "是否接种过新冠疫苗:" );
        jl1.setFont ( new Font ( "华文楷体",1,18 ) );
        jl1.setBounds ( 300 , 100 , 200 , 30 );
        this.jcm1 = new JComboBox<> ( );
        this.jcm1.setFont ( new Font ( "华文楷体",1,18 ) );
        this.jcm1.setBounds ( 510 , 100 , 150 , 30 );
        this.jcm1.addItem ( "--请选择--" );
        this.jcm1.addItem ( "是" );
        this.jcm1.addItem ( "否" );
        String yn=(String)this.jcm1.getSelectedItem ();
        jp.add ( jl1 );
        jp.add ( jcm1 );
        jcm1.addItemListener ( e -> {
            if ( e.getStateChange ( ) == ItemEvent.SELECTED ) {
                if ( e.getItem ( ) == "是" ) {
                    trueJl.setVisible ( true );
                    True_Jl.Tjcm2.setVisible ( true );
                    True_Jl.Tjl5.setVisible ( true );
                    True_Jl.Tjl6.setVisible ( true );
                    True_Jl.Tjt2.setVisible ( true );
                    True_Jl.Tjt3.setVisible ( true );
                    True_Jl.Tjl0.setVisible ( true );

                    False_Jl.Fjl1.setVisible ( false );
                    False_Jl.Fjl2.setVisible ( false );
                    False_Jl.Fjt1.setVisible ( false );
                    False_Jl.Fjt2.setVisible ( false );
                }

                else {

                    trueJl.setVisible ( false );
                    True_Jl.Tjcm2.setVisible ( false );
                    True_Jl.Tjl5.setVisible ( false );
                    True_Jl.Tjl6.setVisible ( false );
                    True_Jl.Tjt2.setVisible ( false );
                    True_Jl.Tjt3.setVisible ( false );
                    True_Jl.Tjl0.setVisible ( false );
                    falseJl.setVisible ( true );

                    False_Jl.Fjl1.setVisible ( true );
                    False_Jl.Fjl2.setVisible ( true );
                    False_Jl.Fjt1.setVisible ( true );
                    False_Jl.Fjt2.setVisible ( true );


                }
            }
        } );


        //接种新冠疫苗类型选项
        jp.add ( trueJl );
        jp.add ( True_Jl.Tjcm2 );
        jp.add ( True_Jl.Tjl5 );
        jp.add ( True_Jl.Tjl6 );
        jp.add ( True_Jl.Tjt2 );
        jp.add ( True_Jl.Tjt3 );
        jp.add(True_Jl.Tjl0);

        jp.add ( falseJl );
        jp.add ( False_Jl.Fjl1 );
        jp.add ( False_Jl.Fjl2 );
        jp.add ( False_Jl.Fjt1 );
        jp.add ( False_Jl.Fjt2 );


        //核酸检测记录选项
        JLabel jl3 = new JLabel ( "核酸检测结果：" );
        jl3.setFont ( new Font ( "华文楷体",1,18 ) );
        jl3.setBounds ( 300 , 590 , 220 , 30 );
        JRadioButton jr1 = new JRadioButton ( "阴性" );
        jr1.setFont ( new Font ( "华文楷体",1,18 ) );
        jr1.setBounds ( 430 , 590 , 160 , 40 );
        JRadioButton jr2 = new JRadioButton ( "阳性" );
        jr2.setForeground ( Color.red );
        jr2.setFont ( new Font ( "华文楷体",1,18 ) );
        jr2.setBounds ( 600 , 590 , 180 , 40 );
        jr2.setFont ( new Font ( "华文隶书" , Font.PLAIN , 18 ) );
        JRadioButton jr3 = new JRadioButton ( "未测" );
        jr3.setFont ( new Font ( "华文楷体",1,18 ) );
        jr3.setBounds ( 780 , 590 , 180 , 40 );


        jp.add ( jl3 );
        jp.add ( jr1 );
        jp.add ( jr2 );
        jp.add ( jr3 );

        JLabel jl4 = new JLabel ( "请输入联系方式：" );
        jl4.setFont ( new Font ( "华文楷体",1,18 ) );
        jl4.setBounds ( 300 , 650 , 200 , 30 );
        JTextField jt1 = new JTextField ( );
        String tele=jl4.getText ();
        jt1.setFont ( new Font ( "华文楷体",1,18 ) );
        jt1.setBounds ( 510 , 650 , 200 , 30 );
        jt1.setHorizontalAlignment ( JTextField.CENTER );    //居中对齐
        jp.add ( jl4 );
        jp.add ( jt1 );


        JButton Commit_Button = new JButton ( "提交" );
        Commit_Button.setFont ( new Font ( "华文楷体",1,18 ) );
        Commit_Button.setBounds ( 460 , 700 , 100 , 30 );
        jp.add ( Commit_Button );
        
        JButton Exist_Button = new JButton("退出");
        Exist_Button.addActionListener(new ActionListener() {
        	public void actionPerformed(ActionEvent e) {
        		backpactureJLabel.setVisible(true);
				dispose();
        	}
        });
        Exist_Button.setFont(new Font("华文楷体", Font.BOLD, 18));
        Exist_Button.setBounds(650, 700, 100, 30);
        jp.add(Exist_Button);
        SimpleDateFormat df= new SimpleDateFormat ( "yyyy年MM月dd日 HH时mm分ss秒" );
        String  now_time = df.format ( System.currentTimeMillis ( ) );
        System.out.println ( now_time );

        jr1.addMouseListener ( new MouseAdapter ( ) {
            @Override
            public
            void mouseClicked ( MouseEvent e ) {
                String jg ="阴性";
                Regist regist=new Regist ( yn,jg,tele );
            }
        } );
        jr2.addMouseListener ( new MouseAdapter ( ) {
            @Override
            public
            void mouseClicked ( MouseEvent e ) {
                String jg ="阳性";
                Regist regist=new Regist ( yn,jg,tele );
            }
        } );
        jr3.addMouseListener ( new MouseAdapter ( ) {
            @Override
            public
            void mouseClicked ( MouseEvent e ) {
                String jg ="未测";
                Regist regist=new Regist ( yn,jg,tele );
            }
        } );


        this.setVisible ( true );
        this.setDefaultCloseOperation ( WindowConstants.EXIT_ON_CLOSE );

    }
private void RegistActionPerformed(  ){
	jcm1.addItemListener(e->{
		String RegistIf = (String) jcm1.getSelectedItem ( );
	    if ( e.getItem ( ) == "是" && StringUtil.isEmpty ( RegistIf ) ) {
	        JOptionPane.showMessageDialog ( null , "请选择你的疫苗接种情况" , "错误" , JOptionPane.ERROR_MESSAGE );
	        return;
	    }

	    String TrueType = (String) True_Jl.Tjcm2.getSelectedItem ( );
	    if ( StringUtil.isEmpty ( TrueType ) ) {
	        JOptionPane.showMessageDialog ( null , "请选择接种疫苗类型" , "错误" , JOptionPane.ERROR_MESSAGE );
	        return;
	    }
	    String Truefield1 = True_Jl.Tjl5.getText ( );
	    if ( e.getItem ( ) == "是" && StringUtil.isEmpty ( Truefield1 ) ) {
	        JOptionPane.showMessageDialog ( null , "请填写第一针接种时间" , "错误" , JOptionPane.ERROR_MESSAGE );
	        return;
	    }
	    String Truejfield2 = True_Jl.Tjl6.getText ( );
	    if ( e.getItem ( ) == "是" && StringUtil.isEmpty ( Truejfield2 ) ) {
	        JOptionPane.showMessageDialog ( null , "请填写第二针接种时间" , "错误" , JOptionPane.ERROR_MESSAGE );
	        return;
	    }
	    String Falsejfield1 = False_Jl.Fjt1.getText ( );
	    if ( e.getItem ( ) == "否" && StringUtil.isEmpty ( Falsejfield1 ) ) {
	        JOptionPane.showMessageDialog ( null , "未填写你的姓名" , "错误" , JOptionPane.ERROR_MESSAGE );
	        return;
	    }
	    String Falsejfield2 = False_Jl.Fjt2.getText ( );
	    if ( e.getItem ( ) == "否" && StringUtil.isEmpty ( Falsejfield2 ) ) {
	        JOptionPane.showMessageDialog ( null , "未填写你的身份证号" , "错误" , JOptionPane.ERROR_MESSAGE );
	        return;
	    }
	    String Ratiobutton_check = jr1.getText ( );
	    if ( Ratiobutton_check == null ) {
	        JOptionPane.showMessageDialog ( null , "未填写你的核酸情况" , "错误" , JOptionPane.ERROR_MESSAGE );
	        return;
	    }
	    String TextField_check = jr1.getText ( );
	    if ( TextField_check == null ) 
	    {
	        JOptionPane.showMessageDialog ( null , "未填写你的联系方式" , "错误" , JOptionPane.ERROR_MESSAGE );
	    }}
	);
}
	

private JPanel getSubmit(){

    //提交
    JPanel submit = new JPanel (  );
    submit.setBackground(new Color(189, 183, 107));

    Commit_Button.addActionListener ( e->{
        RegistActionPerformed ();
        Regist regist = new Regist ( RegistIf,TrueType,Truefield1.getText (),
                                                    Truejfield2.getText (),Falsejfield1.getText (),Falsejfield2.getText (),
                                                    Ratiobutton_check.getText (),TextField_check.getText () );
        Connection con = null;
        try
        {
            con = dbUtil.getCon();
            int n = RegistDao.add ( con, regist );
            if (n == 1)
            {
                JOptionPane.showMessageDialog(null, "提交成功");
            } else
            {
                JOptionPane.showMessageDialog(null, "提交失败");
            }
        } catch (Exception exception)
        {
            exception.printStackTrace();
            JOptionPane.showMessageDialog(null, "提交失败");
        } finally
        {
            try
            {
                dbUtil.closeCon(con);
            } catch (Exception exception)
            {
                exception.printStackTrace();
            }
        }

    } );
    submit.setLayout ( null );


    submit.add(Commit_Button);
    return submit;
}
}

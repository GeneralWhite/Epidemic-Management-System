package test.view;

import test.dao.DeclarationDao;
import test.model.DeclarationModel;
import test.util.DBUtil;
import test.util.StringUtil;
import test.view.Declaration_Component.DateChooser;

import javax.swing.*;
import java.awt.*;
import java.sql.Connection;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class Declaration extends JInternalFrame
{
    private JTextField Name;
    private JTextField Departure;
    private JTextField Time;
    private JTextField Contact;
    private String isNucleic;
    private String isSymptom;
    private String isTorch;
    private final DBUtil dbUtil = new DBUtil();
    private final DeclarationDao declarationDao = new DeclarationDao();
    private static JLabel backpactureJLabel;

    public static void main(String[] args)
    {
    	Declaration frame = new Declaration(backpactureJLabel);
        frame.setVisible(true);
    }

    private JPanel getSlogan()
    {
        JPanel panel = new JPanel();
        panel.setBackground(new Color(189, 183, 107));
        panel.setLayout(new FlowLayout(FlowLayout.CENTER, 50, 5));
        JLabel doctor = new JLabel(new ImageIcon(Declaration.class.getResource("/images/医生.png")));
        JLabel sword = new JLabel(new ImageIcon(Declaration.class.getResource("/images/011剑.png")));
        JLabel virus = new JLabel(new ImageIcon(Declaration.class.getResource("/images/病毒.png")));
        panel.add(doctor);
        panel.add(sword);
        panel.add(virus);

        return panel;
    }
    private void DeclarationActionPerformed()
    {
        String nameId = Name.getText();
        if (StringUtil.isEmpty(nameId))
        {
            JOptionPane.showMessageDialog(null, "姓名不能为空", "错误", JOptionPane.ERROR_MESSAGE);
            return;
        }

        String departureId = Departure.getText();
        if (StringUtil.isEmpty(departureId))
        {
            JOptionPane.showMessageDialog(null, "出发地不能为空", "错误", JOptionPane.ERROR_MESSAGE);
            return;
        }

        String timeId = Time.getText();
        if (StringUtil.isEmpty(timeId))
        {
            JOptionPane.showMessageDialog(null, "到达时间不能为空", "错误", JOptionPane.ERROR_MESSAGE);
            return;
        }

        String contactId = Contact.getText();
        if (StringUtil.isEmpty(contactId))
        {
            JOptionPane.showMessageDialog(null, "联系方式不能为空", "错误", JOptionPane.ERROR_MESSAGE);
            return;
        }

        if (isNucleic == null)
        {
            JOptionPane.showMessageDialog(null, "请填写有无核酸证明", "错误", JOptionPane.ERROR_MESSAGE);
            return;
        }
        if (isSymptom == null)
        {
            JOptionPane.showMessageDialog(null, "请填写是否有症状", "错误", JOptionPane.ERROR_MESSAGE);
            return;
        }
        if (isTorch == null)
        {
            JOptionPane.showMessageDialog(null, "请填写是否有接触", "错误", JOptionPane.ERROR_MESSAGE);
        }
    }

    private JPanel getSubmit()
    {
        // 提交
        JPanel submit = new JPanel();
        submit.setBackground(new Color(189, 183, 107));
        JButton Commit_Button = new JButton("提交");
        Commit_Button.setBounds(369, 24, 97, 38);
        Commit_Button.setFont(new Font("黑体", Font.BOLD, 17));

        // 提交 Button 事件监听，双冒号即简化版 lambda 表达式
        Commit_Button.addActionListener(e ->
        {
            DeclarationActionPerformed();
            DeclarationModel declarationModel = new DeclarationModel(Name.getText(), Departure.getText(), Time.getText(), Contact.getText(), isNucleic, isSymptom, isTorch);
            Connection con = null;
            try
            {
                con = dbUtil.getCon();
                int n = declarationDao.add(con, declarationModel);
                if (n == 1)
                {
                    JOptionPane.showMessageDialog(null, "提交成功");
                } else
                {
                    JOptionPane.showMessageDialog(null, "提交失败");
                }
            } catch (Exception exception)
            {
                exception.printStackTrace();
                JOptionPane.showMessageDialog(null, "提交失败");
            } finally
            {
                try
                {
                    dbUtil.closeCon(con);
                } catch (Exception exception)
                {
                    exception.printStackTrace();
                }
            }
        });
        submit.setLayout(null);


        submit.add(Commit_Button);
        
        JButton Exsit_Button = new JButton("退出");
        Exsit_Button.addActionListener(new ActionListener() {
        	public void actionPerformed(ActionEvent e) {
        		backpactureJLabel.setVisible(true);
				dispose();
        	}
        });
        Exsit_Button.setFont(new Font("黑体", Font.BOLD, 17));
        Exsit_Button.setBounds(567, 24, 97, 38);
        submit.add(Exsit_Button);
        return submit;
    }

    private JPanel getUserName()
    {
        // 姓名
        JPanel name = new JPanel();
        name.setBackground(new Color(189, 183, 107));
        name.setLayout(new FlowLayout(FlowLayout.CENTER, 30, 10));
        JLabel label = new JLabel("申报人姓名");
        label.setFont(new Font("SF Momo", Font.BOLD, 20));
        Name = new JTextField(20);
        Name.setFont(new Font("SF Momo", Font.BOLD, 20));
        name.add(label);
        name.add(Name);


        return name;
    }

    private JPanel getDeparture()
    {
        // 出发地
        JPanel departure = new JPanel();
        departure.setBackground(new Color(189, 183, 107));
        departure.setLayout(new FlowLayout(FlowLayout.CENTER, 72, 10));
        JLabel label = new JLabel("出发地");
        label.setFont(new Font("SF Momo", Font.BOLD, 20));
        Departure = new JTextField(20);
        Departure.setFont(new Font("SF Momo", Font.BOLD, 20));
        departure.add(label);
        departure.add(Departure);


        return departure;
    }

    private JPanel getTime()
    {
        // 到达时间
        JPanel time = new JPanel();
        time.setBackground(new Color(189, 183, 107));
        time.setLayout(new FlowLayout(FlowLayout.CENTER, 51, 10));
        JLabel label = new JLabel("到达时间");
        label.setFont(new Font("SF Momo", Font.BOLD, 20));
        DateChooser dateChooser = DateChooser.getInstance("yyyy-MM-dd");
        Time = new JTextField("单击选择日期", 20);
        Time.setHorizontalAlignment(JTextField.CENTER);
        Time.setFont(new Font("SF Momo", Font.BOLD, 20));
        dateChooser.register(Time);
        time.add(label);
        time.add(Time);

        return time;
    }

    private JPanel getContact()
    {
        // 联系方式
        JPanel contact = new JPanel();
        contact.setBackground(new Color(189, 183, 107));
        contact.setLayout(new FlowLayout(FlowLayout.CENTER, 51, 10));
        JLabel label = new JLabel("联系方式");
        label.setFont(new Font("SF Momo", Font.BOLD, 20));
        Contact = new JTextField(20);
        Contact.setFont(new Font("SF Momo", Font.BOLD, 20));
        contact.add(label);
        contact.add(Contact);

        return contact;
    }

    private JPanel getNucleic()
    {
        // 核酸
        JPanel nucleic = new JPanel();
        nucleic.setBackground(new Color(189, 183, 107));
        JPanel panel = new JPanel();
        panel.setBackground(new Color(189, 183, 107));
        nucleic.setLayout(new GridLayout(2, 1));
        JLabel text = new JLabel("有无48小时核酸证明?", SwingConstants.CENTER);
        text.setFont(new Font("SF MoMo", Font.BOLD, 20));
        JRadioButton nucleicBt1 = new JRadioButton("有");
        nucleicBt1.setFont(new Font("黑体", Font.BOLD, 17));
        JRadioButton nucleicBt2 = new JRadioButton("无");
        nucleicBt2.setFont(new Font("黑体", Font.BOLD, 17));
        ButtonGroup group = new ButtonGroup();
        group.add(nucleicBt1);
        group.add(nucleicBt2);
        nucleicBt1.addActionListener(e -> isNucleic = "是");

        nucleicBt2.addActionListener(e -> isNucleic = "否");

        nucleic.add(text);
        FlowLayout flowLayout = new FlowLayout();
        flowLayout.setHgap(50);
        panel.setLayout(flowLayout);
        panel.add(nucleicBt1);
        panel.add(nucleicBt2);
        nucleic.add(panel);

        return nucleic;
    }

    private JPanel getSymptom()
    {
        // 症状
        JPanel symptom = new JPanel();
        symptom.setBackground(new Color(189, 183, 107));
        JPanel panel = new JPanel();
        panel.setBackground(new Color(189, 183, 107));
        symptom.setLayout(new GridLayout(2, 1));
        JLabel text = new JLabel("近期是否有与新冠病毒感染有关的症状?", SwingConstants.CENTER);
        text.setFont(new Font("SF MoMo", Font.BOLD, 20));
        JRadioButton symptomBt1 = new JRadioButton("是");
        symptomBt1.setFont(new Font("黑体", Font.BOLD, 17));
        JRadioButton symptomBt2 = new JRadioButton("否");
        symptomBt2.setFont(new Font("黑体", Font.BOLD, 17));
        ButtonGroup group = new ButtonGroup();
        group.add(symptomBt1);
        group.add(symptomBt2);

        symptomBt1.addActionListener(e -> isSymptom = "是");
        symptomBt2.addActionListener(e -> isSymptom = "否");

        symptom.add(text);
        FlowLayout flowLayout = new FlowLayout();
        flowLayout.setHgap(50);
        panel.setLayout(flowLayout);
        panel.add(symptomBt1);
        panel.add(symptomBt2);
        symptom.add(panel);

        return symptom;
    }

    private JPanel getTorch()
    {
        // 接触
        JPanel torch = new JPanel();
        torch.setBackground(new Color(189, 183, 107));
        JPanel panel = new JPanel();
        panel.setBackground(new Color(189, 183, 107));
        torch.setLayout(new GridLayout(2, 1));
        JLabel text = new JLabel("是否接触过中高风险区旅居人员？", SwingConstants.CENTER);
        text.setFont(new Font("SF Momo", Font.BOLD, 20));
        JRadioButton torchBt1 = new JRadioButton("是");
        torchBt1.setFont(new Font("黑体", Font.BOLD, 17));
        JRadioButton torchBt2 = new JRadioButton("否");
        torchBt2.setFont(new Font("黑体", Font.BOLD, 17));
        torchBt1.setFont(new Font("黑体", Font.BOLD, 17));
        ButtonGroup group = new ButtonGroup();
        group.add(torchBt1);
        group.add(torchBt2);

        torchBt1.addActionListener(e -> isTorch = "是");
        torchBt2.addActionListener(e -> isTorch = "否");

        torch.add(text);
        FlowLayout flowLayout = new FlowLayout();
        flowLayout.setHgap(50);
        panel.setLayout(flowLayout);
        panel.add(torchBt1);
        panel.add(torchBt2);
        torch.add(panel);

        return torch;
    }

    public Declaration(JLabel backpicture)
    {
    	getContentPane().setBackground(new Color(189, 183, 107));
    	setIconifiable(true);
		setClosable(true);
		Declaration.backpactureJLabel = backpicture;
		setBounds(100, 100, 1028, 783);
		getContentPane().setLayout(new GridLayout(9, 1));
		getContentPane().add(this.getSlogan());
		getContentPane().add(this.getUserName());
        getContentPane().add(this.getDeparture());
        getContentPane().add(this.getTime());
        getContentPane().add(this.getContact());
        getContentPane().add(this.getNucleic());
        getContentPane().add(this.getSymptom());
        getContentPane().add(this.getTorch());
        getContentPane().add(this.getSubmit());
    }
}

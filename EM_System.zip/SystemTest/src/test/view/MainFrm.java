package test.view;

import java.awt.Color;
import java.awt.EventQueue;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JDesktopPane;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import test.model.User;

import javax.swing.JLabel;
import javax.swing.ImageIcon;

import test.view.Declaration_Component.*;

/**
 * ���˵�����
 * @author ������
 *
 */
public class MainFrm extends JFrame {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private JDesktopPane table = null;
	private static User user;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					MainFrm frame = new MainFrm(user);
					// frame.setLocationRelativeTo(null);
					frame.setResizable(false);
					// ��С���ɵ���
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public MainFrm(User user) {
		setResizable(false);
		MainFrm.user = user;
		setTitle("\u75AB\u60C5\u9632\u63A7\u7CFB\u7EDF");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 1260, 820);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JPanel panel = new JPanel();
		panel.setBackground(new Color(102, 205, 170));
		panel.setForeground(new Color(64, 224, 208));
		panel.setBounds(0, 0, 280, 806);
		contentPane.add(panel);
		panel.setLayout(null);
		
		table = new JDesktopPane();
		table.setBackground(Color.CYAN);
		table.setBounds(280, 0, 976, 783);
		contentPane.add(table);
		
		JLabel backPicture = new JLabel("New label");
		backPicture.setIcon(new ImageIcon(MainFrm.class.getResource("/images/\u6B22\u8FCE\u80CC\u666F.jpeg")));
		backPicture.setBounds(0, 0, 966, 783);
		table.add(backPicture);
		
		// ������
		JButton Punch_Button = new JButton("\u5065\u5EB7\u6253\u5361");
		Punch_Button.setFont(new Font("��������", Font.PLAIN, 24));
		Punch_Button.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				PunchFrm interFrm = new PunchFrm(backPicture);
				interFrm.setLocation(-10, -5);
				// ɾ��InternalFrame���ⴰ
				((javax.swing.plaf.basic.BasicInternalFrameUI)interFrm.getUI()).setNorthPane(null);
				backPicture.setVisible(false);
				interFrm.setVisible(true);
				table.add(interFrm);
			}
		});
		Punch_Button.setBounds(0, 181, 280, 125);
		panel.add(Punch_Button);
		
		// �����Ǽ�
		JButton Register_Button = new JButton("\u75AB\u82D7\u63A5\u79CD\u767B\u8BB0");
		Register_Button.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				RegistnationFrm registnationFrm = new RegistnationFrm(backPicture);
				registnationFrm.setLocation(-10, -5);
				// ɾ��InternalFrame���ⴰ
				((javax.swing.plaf.basic.BasicInternalFrameUI)registnationFrm.getUI()).setNorthPane(null);
				backPicture.setVisible(false);
				registnationFrm.setVisible(true);
				table.add(registnationFrm);
			}
		});
		Register_Button.setFont(new Font("��������", Font.PLAIN, 24));
		Register_Button.setBounds(0, 303, 280, 125);
		panel.add(Register_Button);
		
		// ������ѯ
		JButton Regional_Situation_Button = new JButton("\u75AB\u60C5\u67E5\u8BE2");
		Regional_Situation_Button.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Regional_Situation regional_Situation = new Regional_Situation(backPicture);
				regional_Situation.setLocation(-10, -5);
				// ɾ��InternalFrame���ⴰ
				((javax.swing.plaf.basic.BasicInternalFrameUI)regional_Situation.getUI()).setNorthPane(null);
				backPicture.setVisible(false);
				regional_Situation.setVisible(true);
				table.add(regional_Situation);
			}
		});
		Regional_Situation_Button.setFont(new Font("��������", Font.PLAIN, 24));
		Regional_Situation_Button.setBounds(0, 425, 280, 125);
		panel.add(Regional_Situation_Button);
		
		// �����걨
		JButton Declaration_Button = new JButton("\u8FD4\u4E61\u767B\u8BB0");
		Declaration_Button.setFont(new Font("��������", Font.PLAIN, 24));
		Declaration_Button.setBounds(0, 542, 280, 125);
		panel.add(Declaration_Button);
		
		// �����˳�
		JButton Exist_Button = new JButton("\u9000\u51FA\u7CFB\u7EDF");
		Exist_Button.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				int result = JOptionPane.showConfirmDialog(null, "�Ƿ��˳�ϵͳ");
				if(result == 0)
				{
					dispose();
				}
			}
		});
		Exist_Button.setFont(new Font("��������", Font.PLAIN, 24));
		Exist_Button.setBounds(0, 662, 280, 125);
		panel.add(Exist_Button);
		
		JLabel lblNewLabel = new JLabel("\u6B22\u8FCE\u60A8!");
		lblNewLabel.setIcon(null);
		lblNewLabel.setFont(new Font("�����п�", Font.PLAIN, 28));
		lblNewLabel.setBounds(10, 10, 179, 48);
		panel.add(lblNewLabel);
		
		JLabel lblNewLabel_1 = new JLabel(MainFrm.user.getUserName());
		lblNewLabel_1.setFont(new Font("�����п�", Font.PLAIN, 28));
		lblNewLabel_1.setBounds(10, 65, 179, 48);
		panel.add(lblNewLabel_1);
		
		JLabel lblNewLabel_1_1 = new JLabel("ID:"+ user.getId());
		lblNewLabel_1_1.setFont(new Font("���Ŀ���", Font.BOLD, 28));
		lblNewLabel_1_1.setBounds(10, 123, 179, 48);
		panel.add(lblNewLabel_1_1);
		
		JLabel lblNewLabel_2 = new JLabel("");
		lblNewLabel_2.setIcon(new ImageIcon(MainFrm.class.getResource("/images/\u6B22\u8FCE .png")));
		lblNewLabel_2.setBounds(144, 27, 136, 113);
		panel.add(lblNewLabel_2);
		Declaration_Button.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Declaration declarationFrm= new Declaration(backPicture);
				declarationFrm.setLocation(-10, -5);
				// ɾ��InternalFrame���ⴰ
				((javax.swing.plaf.basic.BasicInternalFrameUI)declarationFrm.getUI()).setNorthPane(null);
				backPicture.setVisible(false);
				declarationFrm.setVisible(true);
				table.add(declarationFrm); 
			}
		});
	}
}

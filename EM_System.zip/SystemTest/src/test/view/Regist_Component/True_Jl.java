package test.view.Regist_Component;

import test.model.Regist;

import javax.swing.*;
import java.awt.*;

public
class True_Jl extends JLabel {


    public static JComboBox  Tjcm2;
    public static JLabel     Tjl5;
    public static JLabel     Tjl6;
    public static JTextField Tjt2;
    public static JTextField Tjt3;

    public static JLabel Tjl0;

    public
    True_Jl ( ) {
        this.setVisible ( false );
        this.setText ( "请选择接种疫苗的类型:" );
        this.setFont ( new Font ( "华文隶书",1,18 ) );
        this.setBounds ( 300 , 250 , 170 , 40 );
        Tjcm2 = new JComboBox ( );
        Tjcm2.setFont ( new Font ( "华文隶书",1,18 ) );
        Tjcm2.setBounds ( 480 , 250 , 150 , 40 );
        Tjcm2.setVisible ( false );
        Tjcm2.addItem ( "--请选择--" );
        Tjcm2.addItem ( "北京生物" );
        Tjcm2.addItem ( "武汉生物" );
        Tjcm2.addItem ( "北京科兴" );
        Tjcm2.addItem ( "深圳康泰" );
        Tjcm2.addItem ( "智飞生物" );
        Tjcm2.addItem ( "其他" );
        String type=(String)Tjcm2.getSelectedItem ();

        Tjl5 = new JLabel ( );
        Tjt2 = new JTextField ( );
        Tjl5.setBounds ( 300 , 350 , 300 , 30 );
        Tjt2.setBounds ( 600 , 355 , 150 , 30 );
        Tjl5.setText ( "第一针接种时间：（例：1999-1-1）" );
        String data_1=Tjl5.getText ();
        Tjl5.setFont ( new Font ( "华文隶书",1,18 ) );
        Tjt2.setHorizontalAlignment ( JTextField.CENTER );    //居中对齐
        Tjl5.setVisible ( false );
        Tjt2.setVisible ( false );

        Tjl0 = new JLabel (  );
        Tjl0.setBounds (300,425 ,300,40 );
        Tjl0.setText ( "(如未接种第二针请填 无 )" );
        Tjl0.setFont ( new Font ( "华文隶书",1,18 ) );
        Tjl0.setVisible ( false );

        Tjl6 = new JLabel ( );
        Tjt3 = new JTextField ( );
        Tjl6.setBounds ( 300 , 500 , 300 , 30 );
        Tjt3.setBounds ( 600 , 505 , 150 , 30 );
        Tjl6.setText ( "第二针接种时间：（例：1999-1-1）" );
        String data_2=Tjl6.getText ();
        Tjl6.setFont ( new Font ( "华文隶书",1,18 ) );
        Tjt3.setHorizontalAlignment ( JTextField.CENTER );    //居中对齐
        Tjl6.setVisible ( false );
        Tjt3.setVisible ( false );

        Regist regist=new Regist (type,data_1,data_2,0);


    }
}

package test.view.Regist_Component;

import test.model.Regist;

import javax.swing.*;
import java.awt.*;

public
class False_Jl extends JLabel {
    public static JPanel     Fjp;
    public static JLabel     Fjl1;
    public static JTextField Fjt1;
    public static JLabel Fjl2;
    public static JTextField Fjt2;


    public
    False_Jl ( ) {

        Fjp = new JPanel ( );//错误总框架
        this.setVisible ( false );
        Fjl1 = new JLabel ( "请输入您的姓名：" );
        Fjl1.setFont ( new Font ( "华文隶书",1,18 ) );
        Fjl1.setForeground ( Color.red );
        Fjt1 = new JTextField ( );
        String name = Fjt1.getText ();
        Fjl1.setBounds ( 300 , 300 , 160 , 60 );
        Fjt1.setBounds ( 510 , 310 , 150 , 30 );

        Fjl2 = new JLabel ( "请输入您的I D：" );
        Fjl2.setFont ( new Font ( "华文隶书",1,18 ) );
        Fjl2.setForeground ( Color.red );
        Fjt2 = new JTextField ( );
        String number=Fjt2.getText ();
        Fjl2.setBounds ( 300 , 500 , 200 , 60 );
        Fjt2.setBounds ( 510 , 510 , 150 , 30 );

        Regist regist=new Regist ( name,number );

        Fjl1.setVisible ( true );
        Fjt1.setVisible ( true );
        Fjl2.setVisible ( true );
        Fjt2.setVisible ( true );


        Fjp.setVisible ( false );
        Fjp.add ( Fjl1 );
        Fjp.add ( Fjl2 );
        Fjp.add ( Fjt1 );
        Fjp.add ( Fjt2 );




    }
}

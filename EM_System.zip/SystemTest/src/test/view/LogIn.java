package test.view;
import java.awt.Button;
import java.awt.Color;
import java.awt.EventQueue;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;

import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;
import javax.swing.border.EmptyBorder;

import test.dao.UserDao;
import test.model.User;
import test.util.DBUtil;
import test.util.StringUtil;

/**
 * 登录界面
 * @author 韩乐陶
 *
 */
public class LogIn extends JFrame {

	private JPanel contentPane;
	private JTextField userNameTxt;
	private JPasswordField passwordTxt;
	private DBUtil dbUtil = new DBUtil();
	private UserDao userDao = new UserDao();

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				/**
				 * 界面优化
				 */
				try {
		            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
		                if ("Nimbus".equals(info.getName())) {
		                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
		                    break;
		                }
		            }
		        }catch(Exception e) {
		        	System.out.println(e);
		        }
				
				try {
					LogIn frame = new LogIn();
					// 窗口居中
					frame.setLocationRelativeTo(null);
					// frame.setUndecorated(true);
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public LogIn() {
		// 大小不可调节
		setResizable(false);
		// 设置标题
		setTitle("\u75AB\u60C5\u9632\u63A7\u7BA1\u7406\u7CFB\u7EDF");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		// 设置大小
		setBounds(100, 100, 729, 420);
		// 添加最底层JPanel
		contentPane = new JPanel();
		contentPane.setBackground(Color.WHITE);
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JPanel panel = new JPanel();
		panel.setBackground(Color.BLACK);
		panel.setBounds(0, 0, 370, 383);
		contentPane.add(panel);
		panel.setLayout(null);
		
		// 左侧图片
		JLabel lblNewLabel_1 = new JLabel("New label");
		lblNewLabel_1.setForeground(Color.BLACK);
		lblNewLabel_1.setBounds(47, 26, 318, 256);
		lblNewLabel_1.setIcon(new ImageIcon(LogIn.class.getResource("/images/\u767B\u5F551.png")));
		panel.add(lblNewLabel_1);
		
		// 左侧标语
		JLabel lblNewLabel_2 = new JLabel("\u75AB\u60C5\u5C31\u662F\u547D\u4EE4,\u9632\u63A7\u5C31\u662F\u8D23\u4EFB");
		lblNewLabel_2.setFont(new Font("华文新魏", Font.PLAIN, 20));
		lblNewLabel_2.setForeground(Color.WHITE);
		lblNewLabel_2.setBounds(62, 324, 251, 27);
		panel.add(lblNewLabel_2);
		
		// 登录按钮
		Button sign_button = new Button("Sign  Up");
		sign_button.setFont(new Font("Dialog", Font.BOLD, 14));
		sign_button.setForeground(Color.WHITE);
		sign_button.setBackground(new Color(241, 57, 83));
		// 监听登录按钮
		sign_button.addActionListener(new ActionListener() {
			
			
			public void actionPerformed(ActionEvent e) {
				loginActionPerformed(e);
			}
		});
		sign_button.setBounds(440, 308, 227, 42);
		contentPane.add(sign_button);
		
		userNameTxt = new JTextField();
		userNameTxt.setBounds(440, 110, 227, 42);
		contentPane.add(userNameTxt);
		userNameTxt.setColumns(10);
		
		JLabel name_Label = new JLabel("用户名：");
		name_Label.setFont(new Font("华文楷体", Font.BOLD, 18));
		name_Label.setBounds(441, 75, 94, 25);
		contentPane.add(name_Label);
		
		JLabel Password_label = new JLabel("密码：");
		Password_label.setFont(new Font("华文楷体", Font.BOLD, 18));
		Password_label.setBounds(441, 172, 94, 25);
		contentPane.add(Password_label);
		
		
		passwordTxt = new JPasswordField();
		passwordTxt.setBounds(440, 207, 227, 42);
		contentPane.add(passwordTxt);
	}

	/**
	 * 登录事件处理
	 * @param e
	 */
	private void loginActionPerformed(ActionEvent e) {
		String userName = this.userNameTxt.getText();
		String password = new String(this.passwordTxt.getPassword());
		if(StringUtil.isEmpty(userName))
		{
			JOptionPane.showMessageDialog(null, "用户名不能为空","错误", JOptionPane.ERROR_MESSAGE);
			return;
		}
		if(StringUtil.isEmpty(password))
		{
			JOptionPane.showMessageDialog(null, "密码不能为空","错误", JOptionPane.ERROR_MESSAGE);
			return;
		}
		User user = new User(userName, password);
		Connection con = null;
		try {
			con = dbUtil.getCon();
			User currentUser = userDao.login(con, user);
			if(currentUser != null)
			{
				JOptionPane.showMessageDialog(null, "登陆成功");
				// 销毁当前窗口
				dispose();
				MainFrm mainFrm = new MainFrm(currentUser);
				mainFrm.setLocationRelativeTo(null);
				mainFrm.setVisible(true);
			}
			else {
				JOptionPane.showMessageDialog(null, "用户名或密码错误","错误", JOptionPane.ERROR_MESSAGE);
			}
		} catch (Exception e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
	}
}

package test.view;

import java.awt.EventQueue;

import javax.swing.JInternalFrame;
import javax.swing.JLabel;
import java.awt.Font;
import javax.swing.JTextField;

import test.dao.PunchDao;
import test.model.PunchModel;
import test.util.DBUtil;
import test.util.StringUtil;

import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.awt.event.ActionEvent;
import javax.swing.JComboBox;
import javax.swing.JOptionPane;
import java.awt.Color;
import javax.swing.ImageIcon;

/**
 * �����򿨽���
 * @author ������
 *
 */
public class PunchFrm extends JInternalFrame {
	private JTextField PunchIdTxt;
	private JTextField PunchNameTxt;
	private JTextField PunchTemp;
	//private JTextField PunchDateTxt;
	private JComboBox<String> PunchColorTxt = null;
	private static JLabel backpactureJLabel;
	
	private DBUtil dbUtil = new DBUtil();
	private PunchDao punchDao = new PunchDao();
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					PunchFrm frame = new PunchFrm(backpactureJLabel);
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public PunchFrm(JLabel backpicture) {
		getContentPane().setBackground(new Color(189, 183, 107));
		setTitle("\u75AB\u60C5\u6253\u5361");
		setIconifiable(true);
		setClosable(true);
		setBounds(100, 100, 1028, 783);
		PunchFrm.backpactureJLabel = backpicture;
		
		JLabel ID_Lable = new JLabel("I   D  :");
		ID_Lable.setBounds(181, 169, 151, 62);
		ID_Lable.setFont(new Font("���Ŀ���", Font.BOLD, 23));
		
		JLabel Name_Lable = new JLabel("\u59D3 \u540D\uFF1A");
		Name_Lable.setBounds(181, 277, 151, 62);
		Name_Lable.setFont(new Font("���Ŀ���", Font.BOLD, 23));
		
		JLabel Color_Lable = new JLabel("\u5065\u5EB7\u7801\u989C\u8272\uFF1A");
		Color_Lable.setBounds(181, 396, 151, 62);
		Color_Lable.setFont(new Font("���Ŀ���", Font.BOLD, 23));
		
		JLabel Temp_Lable = new JLabel("\u4F53 \u6E29\uFF1A");
		Temp_Lable.setBounds(181, 502, 151, 62);
		Temp_Lable.setFont(new Font("���Ŀ���", Font.BOLD, 23));
		
		//JLabel lblNewLabel_1_1_1_1 = new JLabel("\u6253\u5361\u65E5\u671F\uFF1A");
		//lblNewLabel_1_1_1_1.setBounds(181, 569, 151, 62);
		//lblNewLabel_1_1_1_1.setFont(new Font("���Ŀ���", Font.BOLD, 23));
		
		PunchIdTxt = new JTextField();
		PunchIdTxt.setBounds(336, 178, 448, 54);
		PunchIdTxt.setColumns(10);
		
		PunchNameTxt = new JTextField();
		PunchNameTxt.setBounds(336, 286, 448, 54);
		PunchNameTxt.setColumns(10);
		
		JButton Commit_Button = new JButton("\u63D0\u4EA4");
		Commit_Button.setBounds(254, 668, 139, 58);
		Commit_Button.setFont(new Font("���Ŀ���", Font.BOLD, 20));
		Commit_Button.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				PunchActionPerformed(e);
			}
		});
		
		JButton Reset_Button = new JButton("\u91CD\u7F6E");
		Reset_Button.setBounds(491, 668, 139, 58);
		Reset_Button.setFont(new Font("���Ŀ���", Font.BOLD, 20));
		Reset_Button.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				resetValueActionPerformed(e);
			}
		});
		getContentPane().setLayout(null);
		getContentPane().add(ID_Lable);
		getContentPane().add(PunchIdTxt);
		//getContentPane().add(lblNewLabel_1_1_1_1);
		getContentPane().add(Color_Lable);
		getContentPane().add(Temp_Lable);
		getContentPane().add(Name_Lable);
		getContentPane().add(Commit_Button);
		getContentPane().add(Reset_Button);
		getContentPane().add(PunchNameTxt);
		
		PunchTemp = new JTextField();
		PunchTemp.setColumns(10);
		PunchTemp.setBounds(336, 511, 448, 54);
		getContentPane().add(PunchTemp);
		
		//PunchDateTxt = new JTextField();
		//PunchDateTxt.setColumns(10);
		//PunchDateTxt.setBounds(336, 569, 448, 54);
		//getContentPane().add(PunchDateTxt);
		
		JButton Exist_Button = new JButton("\u9000\u51FA");
		Exist_Button.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				backpicture.setVisible(true);
				dispose();
			}
		});
		Exist_Button.setFont(new Font("���Ŀ���", Font.BOLD, 18));
		Exist_Button.setBounds(713, 668, 139, 58);
		getContentPane().add(Exist_Button);
		
		PunchColorTxt = new JComboBox<String>();
		PunchColorTxt.setFont(new Font("����", Font.PLAIN, 20));
		PunchColorTxt.setBounds(336, 403, 448, 52);
		PunchColorTxt.addItem("��ѡ�񽡿�����ɫ");
		PunchColorTxt.addItem("��ɫ");
		PunchColorTxt.addItem("��ɫ");
		PunchColorTxt.addItem("��ɫ");
		getContentPane().add(PunchColorTxt);
		
		JLabel example_Lable = new JLabel("\u793A\u4F8B\uFF1A37.2");
		example_Lable.setFont(new Font("���Ŀ���", Font.PLAIN, 16));
		example_Lable.setBounds(794, 520, 98, 30);
		getContentPane().add(example_Lable);
		
		//JLabel lblNewLabel_2_1 = new JLabel("\u793A\u4F8B\uFF1A2022.6.10");
		//lblNewLabel_2_1.setFont(new Font("���Ŀ���", Font.PLAIN, 16));
		//lblNewLabel_2_1.setBounds(794, 585, 139, 30);
		//getContentPane().add(lblNewLabel_2_1);
		
		JLabel Welcome_Lable = new JLabel("\u6B22 \u8FCE \u6765 \u5230 \u5065 \u5EB7 \u6253 \u5361");
		Welcome_Lable.setIcon(new ImageIcon(PunchFrm.class.getResource("/images/\u6253\u5361.png")));
		Welcome_Lable.setForeground(Color.BLACK);
		Welcome_Lable.setFont(new Font("���⵭��ӡ_CNKI", Font.PLAIN, 43));
		Welcome_Lable.setBounds(215, 10, 593, 97);
		getContentPane().add(Welcome_Lable);

	}
	
	/**
	 * �򿨵Ǽ��¼�����
	 */
	private void PunchActionPerformed(ActionEvent evt) {
		String PunchId = this.PunchIdTxt.getText();
		if(StringUtil.isEmpty(PunchId))
		{
			JOptionPane.showMessageDialog(null, "id����Ϊ��","����", JOptionPane.ERROR_MESSAGE);
			return;
		}
		
		String PunchName = this.PunchNameTxt.getText();
		if(StringUtil.isEmpty(PunchName))
		{
			JOptionPane.showMessageDialog(null, "��������Ϊ��","����", JOptionPane.ERROR_MESSAGE);
			return;
		}
		
		String PunchTemp = this.PunchTemp.getText();
		if(StringUtil.isEmpty(PunchTemp))
		{
			JOptionPane.showMessageDialog(null, "���²���Ϊ��","����", JOptionPane.ERROR_MESSAGE);
			return;
		}
		
		Date day=new Date();    
		SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		String PunchDate = df.format(day);
		//String PunchDate = this.PunchDateTxt.getText();
		//if(StringUtil.isEmpty(PunchDate))
		//{
			//JOptionPane.showMessageDialog(null, "���ڲ���Ϊ��","����", JOptionPane.ERROR_MESSAGE);
			//return;
		//}
		
		String PunchColor = (String) this.PunchColorTxt.getSelectedItem();
		if(PunchColor.equals("��ѡ�񽡿�����ɫ"))
		{
			JOptionPane.showMessageDialog(null, "��������ɫ����Ϊ��","����", JOptionPane.ERROR_MESSAGE);
			return;
		}
		
		PunchModel punchModel = new PunchModel(Integer.parseInt(PunchId), PunchName, PunchColor, Float.parseFloat(PunchTemp), PunchDate);
		Connection con = null;
		try {
			con = dbUtil.getCon();
			int n = punchDao.add(con,punchModel);
			if(n == 1 )
			{
				JOptionPane.showMessageDialog(null, "�򿨳ɹ�");
				resetValue();
			}
			else {
				JOptionPane.showMessageDialog(null, "��ʧ��");
			}
		}catch (Exception e) {
			e.printStackTrace();
			JOptionPane.showMessageDialog(null, "��ʧ��");
			// TODO: handle exception
		}finally {
			try {
				dbUtil.closeCon(con);
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}

	
	/**
	 * �����¼�����
	 * @param evt
	 */
	private void resetValueActionPerformed(ActionEvent evt) {
		this.resetValue();
	}

	
	/**
	 * ���ô�
	 */
		private void resetValue()
	{
		this.PunchIdTxt.setText("");
		this.PunchNameTxt.setText("");
		//this.PunchDateTxt.setText("");
		this.PunchTemp.setText("");
		this.PunchColorTxt.setSelectedItem("��ѡ�񽡿�����ɫ");
		
	}
}

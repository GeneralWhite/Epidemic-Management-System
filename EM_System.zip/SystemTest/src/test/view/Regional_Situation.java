package test.view;

import org.jfree.chart.ChartPanel;

import test.view.Regional_Situation_Component.LocalPanel;
import test.view.Regional_Situation_Component.ProvinceTable;
import test.view.Regional_Situation_Component.TimeSeriesChart;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class Regional_Situation extends JInternalFrame
{
	private static JLabel backpactureJLabel;
    public static void main(String[] args)
    {
    	Regional_Situation frame = new Regional_Situation(backpactureJLabel);
        frame.setVisible(true);
    }
    public Regional_Situation(JLabel backpicture)
    {
    	// 界面
    	setIconifiable(true);
		setClosable(true);
		Regional_Situation.backpactureJLabel = backpicture;
		setBounds(100, 100, 1028, 783);
		getContentPane().setLayout(null);

	    // 折线图
	    ChartPanel chart = new TimeSeriesChart().getChartPanel();
	    getContentPane().add(chart);
	    chart.setBounds(0, 0, 966, 350);

	    // 表
	    JPanel table = new ProvinceTable().getPanel();
	    getContentPane().add(table);
	    table.setBounds(5, 400, 400, 383);

	    // 文本框
	    JLabel text = new JLabel("重庆疫情速递", SwingConstants.CENTER);
	    getContentPane().add(text);
	    text.setFont(new Font("华文楷体", (Font.BOLD | Font.ITALIC), 30));
	    text.setForeground(Color.RED);
	    // 字体倾斜加粗
	    text.setBounds(588, 277, 200, 200);

	    // 本地疫情界面
	    JPanel panel = new LocalPanel().getPanel();
	    getContentPane().add(panel);
	    
	    JButton Exist_Button = new JButton("退出");
	    Exist_Button.setFont(new Font("华文楷体", Font.BOLD, 24));
	    Exist_Button.addActionListener(new ActionListener() {
	    	public void actionPerformed(ActionEvent e) {
	    		backpactureJLabel.setVisible(true);
				dispose();
	    	}
	    });
	    Exist_Button.setBounds(782, 727, 148, 46);
	    getContentPane().add(Exist_Button);
	    panel.setBounds(430, 400, 500, 320);

	    this.setResizable(false);
    }
}

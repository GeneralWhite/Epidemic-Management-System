package test.view.Regional_Situation_Component;

import javax.swing.*;

import test.util.ApiCalled.ChongQing;

import java.awt.*;
import java.util.ArrayList;

public class LocalPanel
{
    JPanel panel = new JPanel();
    public JPanel getPanel()
    {
        return panel;
    }
    public static void main(String[] args)
    {
        JFrame frame = new JFrame("Regional Situation");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(966, 783);
        frame.setLocationRelativeTo(null);
        frame.setLayout(null);
        JPanel panel = new LocalPanel().getPanel();
        frame.add(panel);
        panel.setBounds(430, 400, 500, 320);

        frame.setVisible(true);
        frame.setResizable(false);
    }
    public LocalPanel()
    {
        ArrayList<Integer> List = ChongQing.get();
        panel.setLayout(new GridLayout(2,4,5,5));
        JLabel label1 = new JLabel(String.format("<html><font color='black'>现有确诊:</font><font color='#FF7F00'> %d </font></html>", List.get(0)), JLabel.CENTER);
        label1.setFont(new Font("黑体", Font.BOLD, 20));
        label1.setOpaque(true);
//        label1.setText("<html><font color='black'>现有确诊:</font><font color='orange'> 01 </font></html>");


        label1.setBackground(new Color(236, 233, 223));

        JLabel label2 = new JLabel(String.format("<html><font color='black'>本地新增:</font><font color='#551A8B'> %d </font></html>", List.get(1)), JLabel.CENTER);
        label2.setFont(new Font("黑体", Font.BOLD, 20));
        label2.setOpaque(true);
        label2.setBackground(new Color(224, 224, 241));

        JLabel label3 = new JLabel(String.format("<html><font color='black'>累计确诊:</font><font color='#0000FF'> %d </font></html>", List.get(2)), JLabel.CENTER);
        label3.setFont(new Font("黑体", Font.BOLD, 20));
        label3.setOpaque(true);
        label3.setBackground(new Color(213, 238, 239));

        JLabel label4 = new JLabel(String.format("<html><font color='black'>累计治愈:</font><font color='#FF7F00'> %d </font></html>", List.get(3)), JLabel.CENTER);
        label4.setFont(new Font("黑体", Font.BOLD, 20));
        label4.setOpaque(true);
        label4.setBackground(new Color(236, 233, 223));

        JLabel label5 = new JLabel(String.format("<html><font color='black'>累计死亡:</font><font color='#551A8B'> %d </font></html>", List.get(4)), JLabel.CENTER);
        label5.setFont(new Font("黑体", Font.BOLD, 20));
        label5.setOpaque(true);
        label5.setBackground(new Color(224, 224, 241));

        JLabel label6 = new JLabel(String.format("<html><font color='black'>新增治愈:</font><font color='#0000FF'> %d </font></html>", List.get(5)), JLabel.CENTER);
        label6.setFont(new Font("黑体", Font.BOLD, 20));
        label6.setOpaque(true);
        label6.setBackground(new Color(213, 238, 239));
        panel.add(label1);
        panel.add(label2);
        panel.add(label3);
        panel.add(label4);
        panel.add(label5);
        panel.add(label6);

    }
}

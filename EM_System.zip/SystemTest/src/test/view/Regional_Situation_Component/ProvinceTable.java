package test.view.Regional_Situation_Component;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableModel;

import test.util.ApiCalled.Province;

import java.awt.*;
import java.util.ArrayList;

import java.util.Iterator;

public class ProvinceTable
{
    // 创建内容面板
    JPanel panel = new JPanel();

    public ProvinceTable()
    {
        // 表头（列名）
        String[] columnNames = {"省份", "现有确诊", "今日新增"};
        ArrayList<String> provinceList = Province.data().get(0);
        ArrayList<Integer> confirmList = Province.data().get(1);
        ArrayList<Integer> confirmAddList = Province.data().get(2);

        Iterator<String> itProvince = provinceList.iterator();
        Iterator<Integer> itConfirm = confirmList.iterator();
        Iterator<Integer> itConfirmAdd = confirmAddList.iterator();

        Object[][] rowData = {
                {itProvince.next(), itConfirm.next(), itConfirmAdd.next()},
                {itProvince.next(), itConfirm.next(), itConfirmAdd.next()},
                {itProvince.next(), itConfirm.next(), itConfirmAdd.next()},
                {itProvince.next(), itConfirm.next(), itConfirmAdd.next()},
                {itProvince.next(), itConfirm.next(), itConfirmAdd.next()},
                {itProvince.next(), itConfirm.next(), itConfirmAdd.next()},
                {itProvince.next(), itConfirm.next(), itConfirmAdd.next()},
                {itProvince.next(), itConfirm.next(), itConfirmAdd.next()},
                {itProvince.next(), itConfirm.next(), itConfirmAdd.next()},
                {itProvince.next(), itConfirm.next(), itConfirmAdd.next()},
                {itProvince.next(), itConfirm.next(), itConfirmAdd.next()},
                {itProvince.next(), itConfirm.next(), itConfirmAdd.next()},
                {itProvince.next(), itConfirm.next(), itConfirmAdd.next()},
                {itProvince.next(), itConfirm.next(), itConfirmAdd.next()},
                {itProvince.next(), itConfirm.next(), itConfirmAdd.next()},
                {itProvince.next(), itConfirm.next(), itConfirmAdd.next()}
        };

        // 创建一个表格，指定 表头 和 所有行数据
        // 创建 表格模型，指定 所有行数据 和 表头
        TableModel tableModel = new DefaultTableModel(rowData, columnNames);

        // 使用 表格模型 创建 表格
        JTable table = new JTable(tableModel);

        table.setEnabled(false);

        // 设置表格内容颜色
        table.setForeground(Color.BLACK);                   // 字体颜色
        table.setFont(new Font(null, Font.PLAIN, 14));      // 字体样式
        table.setGridColor(Color.GRAY);                     // 网格颜色

        // 设置表头
        table.getTableHeader().setFont(new Font(null, Font.BOLD, 14));  // 设置表头名称字体样式
        table.getTableHeader().setForeground(Color.RED);                // 设置表头名称字体颜色
        table.getTableHeader().setResizingAllowed(false);               // 设置不允许手动改变列宽
        table.getTableHeader().setReorderingAllowed(false);             // 设置不允许拖动重新排序各列


        // 设置行高
        table.setRowHeight(30);


//        // 使用 表格模型 创建 行排序器（TableRowSorter 实现了 RowSorter）
//        RowSorter<TableModel> rowSorter = new TableRowSorter<>(tableModel);
//
//
//
//        // 给 表格 设置 行排序器
//        table.setRowSorter(rowSorter);

        // 把 表头 添加到容器顶部（使用普通的中间容器添加表格时，表头 和 内容 需要分开添加）
        panel.add(table.getTableHeader(), BorderLayout.NORTH);
        // 把 表格内容 添加到容器中心
        panel.add(table, BorderLayout.CENTER);

        // 第一列列宽设置为40
        table.getColumnModel().getColumn(0).setPreferredWidth(40);

        // 设置滚动面板视口大小（超过该大小的行数据，需要拖动滚动条才能看到）
        table.setPreferredScrollableViewportSize(new Dimension(350, 300));

        // 把 表格 放到 滚动面板 中（表头将自动添加到滚动面板顶部）
        JScrollPane scrollPane = new JScrollPane(table);

        // 添加 滚动面板 到 内容面板
        panel.add(scrollPane);

    }
    public JPanel getPanel()
    {
        return panel;
    }
    public static void main(String[] args)
    {
        JFrame jf = new JFrame("测试窗口");
        jf.setSize(968, 783);
        jf.setLayout(null);
        jf.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
        // 设置 内容面板 到 窗口
        JPanel panel = new ProvinceTable().getPanel();
        jf.add(panel);
        panel.setBounds(400, 0, 500, 383);
//        jf.setContentPane(new TestTable().getPanel());


//        jf.setLocationRelativeTo(null);
        jf.setVisible(true);

    }


}

package test.view.Regional_Situation_Component;

import java.awt.*;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Iterator;

import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartPanel;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.axis.DateAxis;
import org.jfree.chart.axis.ValueAxis;
import org.jfree.chart.labels.StandardXYItemLabelGenerator;
import org.jfree.chart.plot.XYPlot;
import org.jfree.chart.renderer.xy.XYItemRenderer;
import org.jfree.chart.renderer.xy.XYLineAndShapeRenderer;
import org.jfree.data.time.*;
import org.jfree.data.xy.XYDataset;

import test.util.ApiCalled.ChinaDayNew_Data;

import javax.swing.*;

public class TimeSeriesChart
{
    ChartPanel frame1;

    public TimeSeriesChart()
    {
        XYDataset xydataset = createDataset();
        JFreeChart jfreechart = ChartFactory.createTimeSeriesChart("全国确诊人数趋势", "日期", "确诊人数", xydataset, true, true, true);
        XYPlot xyplot = (XYPlot) jfreechart.getPlot();
        DateAxis dateaxis = (DateAxis) xyplot.getDomainAxis();
        dateaxis.setDateFormatOverride(new SimpleDateFormat("MM/dd"));
        dateaxis.setTickLabelsVisible(true);
        frame1 = new ChartPanel(jfreechart, true);
        XYPlot plot = (XYPlot) dateaxis.getPlot();
        // 设置数据点可�?
        XYLineAndShapeRenderer xylinerenderer = (XYLineAndShapeRenderer) plot.getRenderer();
        xylinerenderer.setBaseShapesVisible(true);
        XYItemRenderer xyitem = plot.getRenderer();
        // 设置数据点的值可�?
        xyitem.setBaseItemLabelsVisible(true);
//        xyitem.setBasePositiveItemLabelPosition(new ItemLabelPosition(ItemLabelAnchor.OUTSIDE12, TextAnchor.BASELINE_CENTER));

        xyitem.setBaseItemLabelGenerator(new StandardXYItemLabelGenerator());
        // 设置数据点的值显示字�?
        xyitem.setBaseItemLabelFont(new Font("SF Momo", Font.BOLD, 15));

        plot.setRenderer(xyitem);

        dateaxis.setLabelFont(new Font("黑体", Font.BOLD, 14));         //水平底部标题
        dateaxis.setTickLabelFont(new Font("宋体", Font.BOLD, 12));  //垂直标题
        ValueAxis rangeAxis = xyplot.getRangeAxis();//获取柱状
        rangeAxis.setLabelFont(new Font("黑体", Font.BOLD, 15));
        jfreechart.getLegend().setItemFont(new Font("黑体", Font.BOLD, 15));
        jfreechart.getTitle().setFont(new Font("宋体", Font.BOLD, 20));//设置标题字体

    }

    private static XYDataset createDataset()
    {  //这个数据集有点多，但都不难理�?
        TimeSeries timeseries = new TimeSeries("人数", Day.class);


        ArrayList<String> year = ChinaDayNew_Data.data().get(0);
        ArrayList<String> month = ChinaDayNew_Data.data().get(1);
        ArrayList<String> day = ChinaDayNew_Data.data().get(2);
        ArrayList<String> confirm = ChinaDayNew_Data.data().get(3);

        Iterator<String> itYear = year.iterator();
        Iterator<String> itMonth = month.iterator();
        Iterator<String> itDay = day.iterator();
        Iterator<String> itConfirm = confirm.iterator();
        while(itYear.hasNext() && itMonth.hasNext() && itDay.hasNext() && itConfirm.hasNext())
        {
            timeseries.add(new Day(Integer.parseInt(itDay.next()), Integer.parseInt(itMonth.next()), Integer.parseInt(itYear.next())), Integer.parseInt(itConfirm.next()));
        }


        TimeSeriesCollection timeseriescollection = new TimeSeriesCollection();
        timeseriescollection.addSeries(timeseries);
        return timeseriescollection;
    }

    public ChartPanel getChartPanel()
    {
        return frame1;
    }

    public static void main(String[] args)
    {
        JFrame frame = new JFrame("1");
        frame.setLayout(new GridLayout(2,2,10,10));
        frame.add(new TimeSeriesChart().getChartPanel());
        frame.setBounds(50, 50, 800, 600);
        frame.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
        frame.setVisible(true);
    }
}
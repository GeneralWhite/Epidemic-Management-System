package test.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import test.model.Regist;

public
class RegistDao {
    public RegistDao(){
    }
    public static
    int add(Connection con, Regist RegistModel) throws Exception{
        String sql = "insert into RegistTable values(?,?,?,?,?,?,?,?)";
        PreparedStatement pstmt = con.prepareStatement(sql);
        pstmt.setString ( 1,RegistModel.getJcm1 () );
        pstmt.setString ( 2,RegistModel.getTjcm2 () );
        pstmt.setString ( 3,RegistModel.getTjl5 () );
        pstmt.setString ( 4,RegistModel.getTjl6 () );
        pstmt.setString ( 5,RegistModel.getFjt1 () );
        pstmt.setString ( 6,RegistModel.getFjt2 () );
        pstmt.setString ( 7,RegistModel.getJr () );
        pstmt.setString ( 8,RegistModel.getJt1 () );
        return pstmt.executeUpdate ();
    }
}

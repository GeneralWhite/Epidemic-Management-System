package test.dao;

import test.model.DeclarationModel;

import java.sql.Connection;
import java.sql.PreparedStatement;

public class DeclarationDao
{
    public int add(Connection con, DeclarationModel declarationModel) throws Exception
    {
        String sql = "insert into DeclarationTable values(?,?,?,?,?,?,?)";
        PreparedStatement pstmt = con.prepareStatement(sql);
        pstmt.setString(1, declarationModel.getName());
        pstmt.setString(2, declarationModel.getDeparture());
        pstmt.setString(3, declarationModel.getTime());
        pstmt.setString(4, declarationModel.getContact());
        pstmt.setString(5, declarationModel.getNucleic());
        pstmt.setString(6, declarationModel.getSymptom());
        pstmt.setString(7, declarationModel.getTouch());

        return pstmt.executeUpdate();
    }
}

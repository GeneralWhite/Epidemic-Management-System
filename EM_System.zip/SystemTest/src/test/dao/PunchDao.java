package test.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;

import test.model.PunchModel;

/**
 * ��Dao��
 * @author ������
 *
 */
public class PunchDao {
	
	public int add(Connection con, PunchModel punchModel) throws Exception
	{	
		String sql = "insert into PunchTable values(?,?,?,?,?)";
		PreparedStatement pstmt = con.prepareStatement(sql);
		pstmt.setInt(1, punchModel.getId());
		pstmt.setString(2, punchModel.getUserName());
		pstmt.setString(3, punchModel.getCodeColor());
		pstmt.setFloat(4, punchModel.getTemperature());
		pstmt.setString(5, punchModel.getDate());
		return pstmt.executeUpdate();
	}
}

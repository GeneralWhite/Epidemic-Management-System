package test.model;
/**
 * �����ʵ��
 * @author ������
 *
 */
public class PunchModel 
{
	private int id;
	private String userName;
	private String codeColor;
	private float temperature;
	private String date;
	
	public PunchModel() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	public PunchModel(int id, String userName, String codeColor, float temperature, String date) {
		super();
		this.id = id;
		this.userName = userName;
		this.codeColor = codeColor;
		this.temperature = temperature;
		this.date = date;
	}

	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public String getCodeColor() {
		return codeColor;
	}
	public void setCodeColor(String codeColor) {
		this.codeColor = codeColor;
	}
	public float getTemperature() {
		return temperature;
	}
	public void setTemperature(Float temperature) {
		this.temperature = temperature;
	}
	public String getDate() {
		return date;
	}
	public void setDate(String date) {
		this.date = date;
	}
	
}

package test.model;

import java.awt.*;

public
class Regist {
    private String  jcm1 ;//是/否

    private String Tjcm2 ;//疫苗类型
    private String  Tjl5 ;//第一针时间
    private String  Tjl6 ;//第二针时间

    private String  Fjt1 ;//姓名
    private String  Fjt2 ;//身份证号

    private String  jr ;//核酸结果

    private String  jt1 ;//联系方式
    private Button jb;



    public Regist(){
    }
    public Regist(String Fjt1,String Fjt2){
        this.Fjt1=Fjt1;
        this.Fjt2=Fjt2;
    }

    public Regist(String Tjcm2,String Tjl5,String Tjl6,int x){
        this.Tjcm2 = Tjcm2;
        this.Tjl5 = Tjl5;
        this.Tjl6 = Tjl6;
    }

    public Regist(String jcm1,String jr,String jt1){
        this.jcm1=jcm1;
        this.jr=jr;
        this.jt1=jt1;
    }

    public Regist(String jcm1,String Tjcm2,String Tjl5,String Tjl6,
                  String Fjl1,String Fjt2,String jr,String jt1
               ){
        this.Fjt1 = Fjl1;
        this.Fjt2 = Fjt2;
        this.jb = jb;
        this.jr = jr;
        this.jcm1 = jcm1;
        this.jt1 = jt1;
        this.Tjcm2 = Tjcm2;
        this.Tjl5 = Tjl5;
        this.Tjl6 = Tjl6;
    }

    public
    Button getJb ( ) {
        return jb;
    }

    public
    void setJb ( Button jb ) {
        this.jb = jb;
    }

    public
    String getFjt1 ( ) {
        return Fjt1;
    }

    public
    void setFjt1 ( String fjt1 ) {
        Fjt1 = fjt1;
    }

    public
    String getFjt2 ( ) {
        return Fjt2;
    }

    public
    void setFjt2 ( String fjt2 ) {
        Fjt2 = fjt2;
    }

    public
    String getJcm1 ( ) {
        return jcm1;
    }

    public
    void setJcm1 ( String jcm1 ) {
        this.jcm1 = jcm1;
    }

    public
    String getTjcm2 ( ) {
        return Tjcm2;
    }

    public
    void setTjcm2 ( String tjcm2 ) {
        Tjcm2 = tjcm2;
    }

    public
    String getJr ( ) {
        return jr;
    }

    public
    void setJr ( String jr ) {
        this.jr = jr;
    }

    public
    String getJt1 ( ) {
        return jt1;
    }

    public
    void setJt1 ( String jt1 ) {
        this.jt1 = jt1;
    }

    public
    String getTjl5 ( ) {
        return Tjl5;
    }

    public
    void setTjl5 ( String tjl5 ) {
        Tjl5 = tjl5;
    }

    public
    String getTjl6 ( ) {
        return Tjl6;
    }

    public
    void setTjl6 ( String tjl6 ) {
        Tjl6 = tjl6;
    }
}

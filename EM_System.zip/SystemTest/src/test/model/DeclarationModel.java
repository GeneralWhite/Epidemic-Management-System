package test.model;


public class DeclarationModel
{
    private String name;
    private String departure;
    private String time;
    private String contact;
    private String nucleic;
    private String symptom;
    private String touch;

    public DeclarationModel(String name, String departure, String time, String contact, String nucleic, String symptom, String touch)
    {
        this.name = name;
        this.departure = departure;
        this.time = time;
        this.contact = contact;
        this.nucleic = nucleic;
        this.symptom = symptom;
        this.touch = touch;
    }

    public String getContact()
    {
        return contact;
    }

    public String getDeparture()
    {
        return departure;
    }

    public String getName()
    {
        return name;
    }

    public String getNucleic()
    {
        return nucleic;
    }

    public String getSymptom()
    {
        return symptom;
    }

    public String getTime()
    {
        return time;
    }

    public String getTouch()
    {
        return touch;
    }

    public void setContact(String contact)
    {
        this.contact = contact;
    }

    public void setDeparture(String departure)
    {
        this.departure = departure;
    }

    public void setName(String name)
    {
        this.name = name;
    }

    public void setNucleic(String nucleic)
    {
        this.nucleic = nucleic;
    }

    public void setSymptom(String symptom)
    {
        this.symptom = symptom;
    }

    public void setTime(String time)
    {
        this.time = time;
    }

    public void setTouch(String touch)
    {
        this.touch = touch;
    }
}

package test.util.ApiCalled;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.HttpURLConnection;
import java.net.URL;

public class InterfaceRequest
{

    /***
     *   调用第三方或者对方接口方法
     *  @param path 对方或第三方提供的路径
     *  @param data 向对方或第三方发送的数据，大多数情况下给对方发送JSON数据让对方解析
     */
    public static String interfaceDemo(String path, String data)
    {
        try
        {
            URL url = new URL(path);
            //打开和url之间的连接
            HttpURLConnection conn = (HttpURLConnection) url.openConnection();
            PrintWriter out = null;
            //请求方式
            //conn.setRequestMethod("POST");
            //设置通用的请求属性
            conn.setRequestProperty("accept", "*/*");
            conn.setRequestProperty("connection", "Keep-Alive");
            conn.setRequestProperty("user-agent", "Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1; SV1)");
            conn.setDoOutput(true);
            conn.setDoInput(true);
            //获取URLConnection对象对应的输出流
            out = new PrintWriter(conn.getOutputStream());
            //发送请求参数即数据
            out.print(data);
            //缓冲数据
            out.flush();
            //获取URLConnection对象对应的输入流
            InputStream is = conn.getInputStream();
            //构造一个字符流缓存
            BufferedReader br = new BufferedReader(new InputStreamReader(is));
            String str = "";
            StringBuilder stringBuilder = new StringBuilder();
            while ((str = br.readLine()) != null)
            {
                // System.out.println(str);
                stringBuilder.append(str);
            }
            //关闭流
            is.close();
            str = stringBuilder.toString();
            //断开连接，最好写上，disconnect是在底层tcp socket链接空闲时才切断。如果正在被其他线程使用就不切断。
            //固定多线程的话，如果不disconnect，链接会增多，直到收发不出信息。写上disconnect后正常一些。
            conn.disconnect();
            return str;
        } catch (Exception e)
        {
            e.printStackTrace();
        }
        return null;
    }

    public static void main(String[] args)
    {
        //第三方接口api地址 https://view.inews.qq.com/g2/getOnsInfo?name=disease_foreign
        String path = "https://api.inews.qq.com/newsqa/v1/query/inner/publish/modules/list?modules=provinceCompare";
        //需要传送的数据
        String data = "";
        // 忽略interfaceDemo(path, data)为 null 的情况
//        StringBuilder stringBuilder = new StringBuilder(Objects.requireNonNull(interfaceDemo(path, data)));
//        stringBuilder.delete(0, 42);
//        stringBuilder.deleteCharAt(stringBuilder.length() - 1);
//        String s = stringBuilder.toString();
        System.out.println(interfaceDemo(path, data));
//        System.err.println("ok");

        // https://view.inews.qq.com/g2/getOnsInfo?name=wuwei_ww_ww_today_notice&callback=jQuery351001822281952401994_1654515493194&_=1654515493195
        // 每日提示
        // https://api.inews.qq.com/newsqa/v1/query/inner/publish/modules/list?modules=nowConfirmStatis,provinceCompare
        // 各省疫情情况
        // https://api.inews.qq.com/newsqa/v1/automation/modules/list?modules=VaccineTopData
        // 疫苗接种概览

        // https://gwpre.sina.cn/ncp/multi_history_get?citycode=SCUS0001,SCIN0091,SCBR0055,SCFR0033,SCDE0049,SCGB0044,SCRU0007,SCKR0082&callback=dataAPImulti&_=1654592344875
        // 每日情况

        // 疫情概况
        // https://api.inews.qq.com/newsqa/v1/query/inner/publish/modules/list?modules=chinaDayListNew,chinaDayAddListNew&limit=1
        // chinaDayListNew,chinaDayAddListNew&limit=1
        // chinaDayListNew 为中国目前累计确诊情况， chinaDayAddListNew为中国今日最新情况
        // limit=？问号处数字为获取数据天数，0为获取本年度数据


    }
}
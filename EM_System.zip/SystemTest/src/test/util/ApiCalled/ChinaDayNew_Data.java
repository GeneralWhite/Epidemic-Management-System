package test.util.ApiCalled;


import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;

import java.util.ArrayList;
import java.util.Objects;

public class ChinaDayNew_Data
{
    public static void main(String[] args)
    {
        data();
    }
    public static ArrayList<ArrayList<String>> data()
    {
        ArrayList<ArrayList<String>> List = new ArrayList<>();
        ArrayList<String> yearList = new ArrayList<>();
        ArrayList<String> monthList = new ArrayList<>();
        ArrayList<String> dayList = new ArrayList<>();
        ArrayList<String> confirmList  = new ArrayList<>();
        String path = "https://api.inews.qq.com/newsqa/v1/query/inner/publish/modules/list?modules=chinaDayListNew&limit=15";
        String data = "";
        StringBuilder stringBuilder = new StringBuilder(Objects.requireNonNull(InterfaceRequest.interfaceDemo(path, data)));
        stringBuilder.deleteCharAt(stringBuilder.length() - 1);
        stringBuilder.delete(0, 26);
        String s = stringBuilder.toString();
        //System.out.println(s);


        // 3,解析带有数组(集合)的json字符串
        // 定义json字符串
        //将json字符串json格式化
        JSONObject jsonObject1 = JSON.parseObject(s);
        //获取json字符串中的chinaDayListNew,chinaDayListNew为jsonarray类型
        JSONArray data2 = jsonObject1.getJSONArray("chinaDayListNew");
        //遍历data2 JSONArray数组
        //JSONArray的类型为Object
        for (Object obj : data2)
        {
            //循环打印
            JSONObject jsonObject2 = JSON.parseObject(obj.toString());
            String year = jsonObject2.getString("y");
            String date = jsonObject2.getString("date");
            String[] part = date.split("\\.");

            yearList.add(year);
            monthList.add(part[0]);
            dayList.add(part[1]);

            String localConfirm = jsonObject2.getString("localConfirm");
            confirmList.add(localConfirm);
        }
        List.add(yearList);
        List.add(monthList);
        List.add(dayList);
        List.add(confirmList);
        return List;
    }
}

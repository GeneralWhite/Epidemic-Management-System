package test.util.ApiCalled;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;

import java.util.ArrayList;
import java.util.Objects;

public class ChongQing
{
    public static void main(String[] args)
    {
        get();
    }
    public static ArrayList<Integer> get()
    {
        String path = "https://api.inews.qq.com/newsqa/v1/query/pubished/daily/list?adCode=500000&limit=1";
        String data = "";
        StringBuilder stringBuilder = new StringBuilder(Objects.requireNonNull(InterfaceRequest.interfaceDemo(path, data)));
        stringBuilder.delete(0, 27);
        stringBuilder.delete(stringBuilder.length() - 3, stringBuilder.length() - 1);
        String s = stringBuilder.toString();
//        System.out.println(s);

        JSONObject jsonObject = JSON.parseObject(s);
        Integer totalConfirm = jsonObject.getInteger("confirm");
        Integer dead = jsonObject.getInteger("dead");
        Integer heal = jsonObject.getInteger("heal");
        Integer confirm_add = jsonObject.getInteger("confirm_add");
        Integer newHeal = jsonObject.getInteger("newHeal");
        int confirm = totalConfirm - dead - heal;
//        String year = jsonObject.getString("year");
//        String date = jsonObject.getString("date");
//        String[] parts = date.split("\\.");

//        System.out.println(year + "�?" + parts[0] + "�?" + parts[1] + "日本地疫情");
//        System.out.println("现有确诊: " + confirm);
//        System.out.println("本地新增: " + confirm_add);
//        System.out.println("累计确诊: " + totalConfirm);
//        System.out.println("累计治愈: " + heal);
//        System.out.println("累计死亡: " + dead);
//        System.out.println("新增治愈: " + newHeal);

        ArrayList<Integer> List = new ArrayList<>();
        List.add(confirm);
        List.add(confirm_add);
        List.add(totalConfirm);
        List.add(heal);
        List.add(dead);
        List.add(newHeal);

        return List;
    }
}

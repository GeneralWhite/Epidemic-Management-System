package test.util.ApiCalled;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;

import java.util.ArrayList;
import java.util.Objects;

public class Province
{
    public static void main(String[] args)
    {
        data();
    }
    public static ArrayList<ArrayList> data()
    {
        ArrayList<Integer> identity = new ArrayList<>();
        identity.add(11);  // 北京代号
        identity.add(12);  // 天津
        identity.add(13);  // 河北
        identity.add(14);  // 山西
        identity.add(15);  // 内蒙
        identity.add(21);  // 辽宁
        identity.add(22);  // 吉林
        identity.add(23);  // 黑龙
        identity.add(31);  // 上海
        identity.add(32);  // 江苏
        identity.add(33);  // 浙江
//        identity.add(34);  // 安徽
//        identity.add(35);  // 福建
//        identity.add(36);  // 江西
        identity.add(37);  // 山东
//        identity.add(41);  // 河南
        identity.add(42);  // 湖北
//        identity.add(43);  // 湖南
        identity.add(44);  // 广东
        identity.add(45);  // 广西
//        identity.add(50);  // 重庆
        identity.add(51);  // 四川
//        identity.add(52);  // 贵州
//        identity.add(53);  // 云南
//        identity.add(54);  // 西藏
//        identity.add(61);  // 陕西
//        identity.add(62);  // 甘肃
//        identity.add(63);  // 青海
//        identity.add(64);  // 宁夏
//        identity.add(65);  // 新疆
//        identity.add(71);  // 台湾
//        identity.add(81);  // 香港
//        identity.add(82);  // 澳门

        ArrayList<String> provinceList = new ArrayList<>();
        ArrayList<Integer> confirmList = new ArrayList<>();
        ArrayList<Integer> confirmAddList = new ArrayList<>();
        for(int i: identity)
        {
            // 获取列表�? 改变500000 为身份证号前几位。
            String path = String.format("https://api.inews.qq.com/newsqa/v1/query/pubished/daily/list?adCode=%d0000&limit=1", i);
            String data = "";
            StringBuilder stringBuilder = new StringBuilder(Objects.requireNonNull(InterfaceRequest.interfaceDemo(path, data)));
            stringBuilder.delete(0, 27);
            stringBuilder.delete(stringBuilder.length() - 3, stringBuilder.length() - 1);
            String s = stringBuilder.toString();
//            System.out.println(s);

            JSONObject jsonObject = JSON.parseObject(s);
            Integer totalConfirm = jsonObject.getInteger("confirm");
            Integer dead = jsonObject.getInteger("dead");
            Integer heal = jsonObject.getInteger("heal");
            Integer confirm_add = jsonObject.getInteger("confirm_add");
            int confirm = totalConfirm - dead - heal;
//            String year = jsonObject.getString("year");
//            String date = jsonObject.getString("date");
            String province = jsonObject.getString("province");
//            String[] parts = date.split("\\.");
//
//            System.out.println(year + "�?" + parts[0] + "�?" + parts[1] + "日本地疫情");
//            System.out.println("省份: " + province);
//            System.out.println("现有确诊: " + confirm);
//            System.out.println("本地新增: " + confirm_add);
            provinceList.add(province);
            confirmList.add(confirm);
            confirmAddList.add(confirm_add);
        }
        ArrayList<ArrayList> List = new ArrayList<>();
        List.add(provinceList);
        List.add(confirmList);
        List.add(confirmAddList);

        return List;
    }
}
